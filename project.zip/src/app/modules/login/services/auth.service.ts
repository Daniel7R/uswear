import { Injectable, inject } from '@angular/core';
import { Auth, createUserWithEmailAndPassword, signInWithEmailAndPassword, updateProfile } from '@angular/fire/auth';
import { Observable, from } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  _firabaseAuth= inject(Auth)
  constructor() { }

  login(username: string, password: string): Observable<any>{
    const promise= signInWithEmailAndPassword(this._firabaseAuth,username, password).then(response => {
      console.log(response);
      
    })
    return from(promise)
  }

  // async logout(){
  //   return await signOut(getAuth());
  // }

  signup(email: string, username:string,password: string): Observable<void> {
    const promise=  createUserWithEmailAndPassword(this._firabaseAuth,email, password).then(response=> updateProfile(response.user,{displayName: username} ));

    return from(promise)
  }
}
