import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import {FloatLabelModule} from 'primeng/floatlabel'
import { InputTextModule } from 'primeng/inputtext';
import { AuthService } from '../../services/auth.service';


@Component({
  selector: 'app-form',
  standalone: true,
  imports: [FormsModule,  ButtonModule, FloatLabelModule,InputTextModule],
  templateUrl: './form.component.html',
  styleUrl: './form.component.scss',
  providers: [AuthService]
})
export class FormComponent {
  username: string ="";
  password: string ="";

  constructor(private _authService: AuthService){}

  login(){
    try{
      this._authService.login(this.username, this.password);
    } catch(error){
      console.log(error);
    }
  }

  
}
