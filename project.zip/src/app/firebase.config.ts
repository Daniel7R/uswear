
import { ENVIRONMENT } from "../environments/environment";

export const firebaseConfig = ENVIRONMENT.firebaseConfig;