export const ENVIRONMENT={
    firebaseConfig: {
        apiKey: "AIzaSyD_51-Zo7Zgax-ARJr1qOqykdmFgzrveRw",
        authDomain: "e-commerce-831f0.firebaseapp.com",
        projectId: "e-commerce-831f0",
        storageBucket: "e-commerce-831f0.appspot.com",
        messagingSenderId: "167835174915",
        appId: "1:167835174915:web:f7cec1acb8cba3e55aa636"
      }
}